
from pydantic import BaseModel

# the data you are expecting from the client
class Base(BaseModel):

    uname: str
    sclass: str
    section: str
