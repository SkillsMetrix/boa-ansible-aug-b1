from rbiclass import RBI

class SBI(RBI):
    def withdraw(self):
        print("withdraw from SBI")
     
    def deposit(self):
        print("deposit from SBI")
     
    def checkBalance(self):
        print("check from SBI")
        
    def openFD(self):
        print('FD account opened in SBI')
