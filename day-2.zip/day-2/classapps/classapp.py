class User:
    # constructor
    def __init__(self,uname,email,city):
        self.uname=uname
        self.email=email
        self.city=city

    # def __init__(self):
    #     print('default cons called')
    # this fun auto called when you are printing object
    def __str__(self):
        return f"{self.uname} - {self.email} - {self.city} "

    def showCity(self):
        city=input('Enter city')
        print('city will be called ', city)

# constructor is getting called
user1= User('Admin','admin@mail.com','pune')
user2= User('Manager','manager@mail.com','Mumbai')
print(user1)
print(user2)
#user= User()

#user1.showCity()