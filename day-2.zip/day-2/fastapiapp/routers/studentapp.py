
from fastapi import FastAPI,APIRouter,Depends,status
from fastapi.params import Body
from sqlalchemy.orm import Session
from .. import schema,models
from .. database import engine,get_connection


router= APIRouter(tags=["Student Application"])

@router.post("/addstudent")
def studentRegister(student:schema.Base, db:Session=Depends(get_connection)):
    
    newdata=models.Student(**student.dict())
    db.add(newdata)
    db.commit()
    return {"message":"db created"}