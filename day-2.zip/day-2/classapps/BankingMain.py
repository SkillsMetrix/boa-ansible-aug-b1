
from sbiclass import SBI

bank1= SBI()
bank1.openFD()
bank1.checkBalance()